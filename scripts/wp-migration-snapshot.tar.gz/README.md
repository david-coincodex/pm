# WordPress migration (gitignored)

One-off tooling and data for recreating the 85 legacy pornmode.com blog posts in Strapi.
This whole folder is gitignored — it is scaffolding, not product code.

## The part that matters

`data/wp-articles.json` and `data/wp-bodies/*.html` are the **only** record of the legacy
articles' original publish dates, body text, media URLs and `/go/` affiliate targets. None of it
can be reconstructed once WordPress is decommissioned. Because the folder is gitignored, a
committed snapshot is kept one level up:

    ../wp-migration-snapshot.tar.gz

Refresh it after any re-harvest:

    ./snapshot.sh

`data/wp-archive/` (mirrored media, ~410 MB) is deliberately NOT in the snapshot — it is too
large for git, and everything actually used has already been uploaded into Strapi. If you need
it after cutover, restore from a machine backup.

## What is here

| Script | Purpose |
|---|---|
| `harvest-wp-articles.mjs` | Scrape all 85 posts → `data/`. `--verify` re-harvests and diffs. Merges, never replaces. |
| `import-legacy-articles.mjs` | Track A: verbatim archive import (17 articles), original dates preserved. |
| `backfill-article-dates.mjs` | Restore original publish dates onto already-recreated articles. |
| `verify-articles.mjs` | Quality gate: postId parity, dead links, widget integrity, video count, media hygiene. |
| `migrate-widget-ids.mjs` | One-off: numeric site ids → documentIds in article bodies. |
| `migrate-media-urls.mjs` | One-off: absolute `http://host/uploads/...` → relative `/uploads/...`. |
| `migrate-internal-links.mjs` | Repoint `/blog/<id>/<slug>/` links at the current slug; `--unlink-dead`. |
| `build-wp-post-ids.mjs` | Rebuild `../data/wp-post-ids.json` from the WP sitemap. |
| `toplist-jobs-batch*.json`, `toplist-jobs-refresh.json` | The job definitions each recreated article was generated from. |

## What deliberately stayed outside this folder

- `../data/wp-post-ids.json` — the permanent legacy `slug -> postId` map. The ongoing generators
  need it to keep URLs matching what Google has indexed, so it stays committed.
- `../lib/{http,strapi,jobs}.mjs` — shared with the generators. Only `lib/wp.mjs` (WordPress
  markup parsing) and `lib/wp-data.mjs` are local to this folder.
- `../cleanup-orphaned-media.mjs` — general maintenance, not migration-specific.

## Order of operations

    node harvest-wp-articles.mjs              # must run while WordPress is still up
    node harvest-wp-articles.mjs --verify     # re-harvest + diff; expect "stable"
    node backfill-article-dates.mjs --dry-run
    node import-legacy-articles.mjs --dry-run
    node verify-articles.mjs                  # expect 0 errors
